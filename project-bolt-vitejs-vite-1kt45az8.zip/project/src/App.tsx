import React, { useEffect, useState } from 'react';
import { Github, Linkedin, Mail, ExternalLink, Code, Database, GitBranch, ChevronDown, Star, Zap, Heart } from 'lucide-react';
import './App.css';

function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    setIsLoaded(true);
    
    const handleScroll = () => {
      const sections = ['hero', 'skills', 'experience', 'projects', 'contact'];
      const scrollPosition = window.scrollY + window.innerHeight / 2;
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="portfolio">
      {/* Animated Background */}
      <div className="animated-bg">
        <div className="floating-shapes">
          <div className="shape shape-1"></div>
          <div className="shape shape-2"></div>
          <div className="shape shape-3"></div>
          <div className="shape shape-4"></div>
          <div className="shape shape-5"></div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="nav-bar">
        <div className="nav-container">
          <div className="nav-logo">
            <span className="logo-text">VK</span>
          </div>
          <div className="nav-links">
            {['Skills', 'Experience', 'Projects', 'Contact'].map((item) => (
              <button
                key={item}
                className={`nav-link ${activeSection === item.toLowerCase() ? 'active' : ''}`}
                onClick={() => scrollToSection(item.toLowerCase())}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero" className={`hero ${isLoaded ? 'loaded' : ''}`}>
        <div className="hero-content">
          <div className="hero-badge">
            <Zap size={16} />
            <span>Available for work</span>
          </div>
          <h1 className="hero-title">
            <span className="title-line">Hi, I'm</span>
            <span className="title-line gradient-text">Vamsikrishna</span>
          </h1>
          <p className="hero-subtitle">
            <span className="typing-text">Software Developer</span>
          </p>
          <p className="hero-description">
            Crafting digital experiences with modern technologies and creative solutions
          </p>
          <div className="hero-buttons">
            <button className="cta-button primary" onClick={() => scrollToSection('contact')}>
              <span>Let's Connect</span>
              <ExternalLink size={18} />
            </button>
            <button className="cta-button secondary" onClick={() => scrollToSection('projects')}>
              <span>View Work</span>
            </button>
          </div>
          <div className="hero-stats">
            <div className="stat">
              <span className="stat-number">3+</span>
              <span className="stat-label">Years Experience</span>
            </div>
            <div className="stat">
              <span className="stat-number">50+</span>
              <span className="stat-label">Projects Completed</span>
            </div>
            <div className="stat">
              <span className="stat-number">100%</span>
              <span className="stat-label">Client Satisfaction</span>
            </div>
          </div>
        </div>
        <div className="scroll-indicator" onClick={() => scrollToSection('skills')}>
          <ChevronDown size={24} />
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="skills-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">
              <span className="title-number">01</span>
              Skills & Technologies
            </h2>
            <p className="section-subtitle">
              Technologies I love working with
            </p>
          </div>
          <div className="skills-grid">
            {[
              { name: 'HTML', icon: 'H', color: '#e34f26', level: 95 },
              { name: 'CSS3', icon: '≡', color: '#1572b6', level: 90 },
              { name: 'JavaScript', icon: 'JS', color: '#f7df1e', level: 88 },
              { name: 'React', icon: '⚛', color: '#61dafb', level: 92 },
              { name: 'Node.js', icon: '⬢', color: '#339933', level: 85 },
              { name: 'MongoDB', icon: '🍃', color: '#47a248', level: 80 },
              { name: 'Git', icon: <GitBranch size={20} />, color: '#f05032', level: 90 },
              { name: 'GitHub', icon: <Github size={20} />, color: '#333', level: 88 }
            ].map((skill, index) => (
              <div key={skill.name} className="skill-card" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="skill-icon" style={{ backgroundColor: skill.color }}>
                  {typeof skill.icon === 'string' ? (
                    <span className="skill-icon-text">{skill.icon}</span>
                  ) : (
                    skill.icon
                  )}
                </div>
                <div className="skill-info">
                  <span className="skill-name">{skill.name}</span>
                  <div className="skill-level">
                    <div className="skill-bar">
                      <div 
                        className="skill-progress" 
                        style={{ width: `${skill.level}%`, backgroundColor: skill.color }}
                      ></div>
                    </div>
                    <span className="skill-percentage">{skill.level}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="experience-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">
              <span className="title-number">02</span>
              Experience
            </h2>
            <p className="section-subtitle">
              My professional journey
            </p>
          </div>
          <div className="experience-timeline">
            <div className="timeline-line"></div>
            <div className="experience-item">
              <div className="experience-date">
                <span className="date-range">Jan 2022</span>
                <span className="date-present">Present</span>
              </div>
              <div className="experience-content">
                <div className="company-info">
                  <div className="company-icon">
                    <Code size={24} />
                  </div>
                  <div>
                    <h3 className="company-name">Tech Company</h3>
                    <p className="job-title">Senior Software Engineer</p>
                  </div>
                </div>
                <p className="job-description">
                  Led development of scalable web applications using React and Node.js. 
                  Collaborated with cross-functional teams to deliver high-quality solutions 
                  that improved user engagement by 40%.
                </p>
                <div className="job-tags">
                  <span className="tag">React</span>
                  <span className="tag">Node.js</span>
                  <span className="tag">MongoDB</span>
                  <span className="tag">AWS</span>
                </div>
              </div>
            </div>
            
            <div className="experience-item">
              <div className="experience-date">
                <span className="date-range">Jun 2020</span>
                <span className="date-present">Dec 2021</span>
              </div>
              <div className="experience-content">
                <div className="company-info">
                  <div className="company-icon university">
                    <Database size={24} />
                  </div>
                  <div>
                    <h3 className="company-name">StartupCo</h3>
                    <p className="job-title">Full Stack Developer</p>
                  </div>
                </div>
                <p className="job-description">
                  Built responsive web applications from scratch. Implemented RESTful APIs 
                  and optimized database queries, resulting in 60% faster load times.
                </p>
                <div className="job-tags">
                  <span className="tag">JavaScript</span>
                  <span className="tag">Express</span>
                  <span className="tag">PostgreSQL</span>
                  <span className="tag">Docker</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="projects-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">
              <span className="title-number">03</span>
              Featured Projects
            </h2>
            <p className="section-subtitle">
              Some of my recent work
            </p>
          </div>
          <div className="projects-grid">
            {[
              {
                title: 'E-Commerce Platform',
                description: 'Full-stack e-commerce solution with React, Node.js, and Stripe integration',
                image: 'laptop',
                tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
                featured: true
              },
              {
                title: 'Analytics Dashboard',
                description: 'Real-time data visualization dashboard with interactive charts',
                image: 'tablet',
                tags: ['React', 'D3.js', 'WebSocket', 'Express']
              },
              {
                title: 'Mobile Banking App',
                description: 'Secure mobile banking interface with biometric authentication',
                image: 'phone',
                tags: ['React Native', 'Firebase', 'Biometrics']
              }
            ].map((project, index) => (
              <div key={project.title} className={`project-card ${project.featured ? 'featured' : ''}`}>
                {project.featured && (
                  <div className="featured-badge">
                    <Star size={16} />
                    <span>Featured</span>
                  </div>
                )}
                <div className="project-image">
                  <div className={`project-mockup ${project.image}`}>
                    <div className="screen">
                      {project.image === 'laptop' && (
                        <>
                          <div className="browser-bar">
                            <div className="browser-dots">
                              <span></span>
                              <span></span>
                              <span></span>
                            </div>
                          </div>
                          <div className="screen-content">
                            <div className="content-lines">
                              <div className="line"></div>
                              <div className="line short"></div>
                              <div className="line"></div>
                              <div className="button-demo"></div>
                            </div>
                          </div>
                        </>
                      )}
                      {project.image === 'tablet' && (
                        <div className="chart-container">
                          <div className="chart-bars">
                            <div className="bar" style={{height: '30%'}}></div>
                            <div className="bar" style={{height: '50%'}}></div>
                            <div className="bar" style={{height: '70%'}}></div>
                            <div className="bar" style={{height: '90%'}}></div>
                            <div className="bar" style={{height: '60%'}}></div>
                            <div className="bar" style={{height: '80%'}}></div>
                          </div>
                        </div>
                      )}
                      {project.image === 'phone' && (
                        <div className="phone-content">
                          <div className="app-grid">
                            <div className="app-icon blue">A</div>
                            <div className="app-icon yellow">B</div>
                            <div className="app-icon red">C</div>
                            <div className="app-icon green">D</div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="project-content">
                  <h3 className="project-title">{project.title}</h3>
                  <p className="project-description">{project.description}</p>
                  <div className="project-tags">
                    {project.tags.map(tag => (
                      <span key={tag} className="project-tag">{tag}</span>
                    ))}
                  </div>
                  <div className="project-links">
                    <button className="project-link">
                      <ExternalLink size={16} />
                      <span>Live Demo</span>
                    </button>
                    <button className="project-link secondary">
                      <Github size={16} />
                      <span>Code</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="contact-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">
              <span className="title-number">04</span>
              Let's Work Together
            </h2>
            <p className="section-subtitle">
              Ready to bring your ideas to life
            </p>
          </div>
          <div className="contact-content">
            <div className="contact-info">
              <h3>Get in touch</h3>
              <p>
                I'm always excited to work on new projects and collaborate with 
                amazing people. Let's create something incredible together!
              </p>
              <div className="contact-details">
                <div className="contact-item">
                  <Mail size={20} />
                  <span>vamsikrishna@example.com</span>
                </div>
                <div className="contact-item">
                  <Github size={20} />
                  <span>github.com/vamsikrishna</span>
                </div>
                <div className="contact-item">
                  <Linkedin size={20} />
                  <span>linkedin.com/in/vamsikrishna</span>
                </div>
              </div>
            </div>
            <div className="contact-form">
              <form>
                <div className="form-group">
                  <input type="text" placeholder="Your Name" required />
                </div>
                <div className="form-group">
                  <input type="email" placeholder="Your Email" required />
                </div>
                <div className="form-group">
                  <textarea placeholder="Your Message" rows={5} required></textarea>
                </div>
                <button type="submit" className="submit-button">
                  <span>Send Message</span>
                  <Heart size={18} />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <p>&copy; 2024 Vamsikrishna. Crafted with passion and code.</p>
            <div className="footer-links">
              <a href="mailto:vamsikrishna@example.com">
                <Mail size={18} />
              </a>
              <a href="https://linkedin.com/in/vamsikrishna">
                <Linkedin size={18} />
              </a>
              <a href="https://github.com/vamsikrishna">
                <Github size={18} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;